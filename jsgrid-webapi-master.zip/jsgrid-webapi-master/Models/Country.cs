﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JSGridWebAPISample.Models {

    public enum Country {
        UnitedStates = 1,
        Canada = 2,
        UnitedKingdom = 3,
        France = 4,
        Brazil = 5,
        China = 6,
        Russia = 7
    }

}