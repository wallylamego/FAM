# jsgrid-webapi
Sample project for jsgrid with WebAPI remote source
